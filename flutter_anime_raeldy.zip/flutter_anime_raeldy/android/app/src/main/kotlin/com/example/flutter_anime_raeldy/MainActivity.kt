package com.example.flutter_anime_raeldy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
