class Anime {
  final int malId;
  final String title;
  final String? titleJapanese;
  final String? imageUrl;
  final String? type;
  final int? episodes;
  final double? score;
  final String? status;
  final String? synopsis;
  final String? aired;
  final List<String> genres;
  final List<String> studios;
  final int? rank;
  final int? popularity;

  Anime({
    required this.malId,
    required this.title,
    this.titleJapanese,
    this.imageUrl,
    this.type,
    this.episodes,
    this.score,
    this.status,
    this.synopsis,
    this.aired,
    this.genres = const [],
    this.studios = const [],
    this.rank,
    this.popularity,
  });

  factory Anime.fromJson(Map<String, dynamic> json) {
    return Anime(
      malId: json['mal_id'] ?? 0,
      title: json['title'] ?? 'Tidak Diketahui',
      titleJapanese: json['title_japanese'],
      imageUrl: json['images']?['jpg']?['large_image_url'] ?? 
                json['images']?['jpg']?['image_url'],
      type: json['type'],
      episodes: json['episodes'],
      score: json['score']?.toDouble(),
      status: json['status'],
      synopsis: json['synopsis'],
      aired: json['aired']?['string'],
      genres: (json['genres'] as List<dynamic>?)
          ?.map((genre) => genre['name'].toString())
          .toList() ?? [],
      studios: (json['studios'] as List<dynamic>?)
          ?.map((studio) => studio['name'].toString())
          .toList() ?? [],
      rank: json['rank'],
      popularity: json['popularity'],
    );
  }

  // Helper method untuk mendapatkan genre string yang dibatasi
  String get genresString {
    if (genres.isEmpty) return '';
    return genres.take(2).join(', ');
  }

  // Helper method untuk mendapatkan rating string
  String get ratingString {
    return score != null ? score!.toStringAsFixed(1) : 'N/A';
  }

  // Helper method untuk mendapatkan episodes string
  String get episodesString {
    return episodes != null ? '$episodes ep' : 'Unknown';
  }
}