import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'pages/main_screen.dart';

void main() {
  runApp(const RanimeListApp());
}

class RanimeListApp extends StatelessWidget {
  const RanimeListApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RanimeList',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF00ff88),
        scaffoldBackgroundColor: const Color(0xFF0f0f0f),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1a1a1a),
          elevation: 0,
          centerTitle: false,
          systemOverlayStyle: SystemUiOverlayStyle.light,
        ),
        cardTheme: const CardTheme(
          color: Color(0xFF1a1a1a),
          elevation: 8,
          shadowColor: Color(0x4000ff88),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Color(0xFF1a1a1a),
          selectedItemColor: Color(0xFF00ff88),
          unselectedItemColor: Color(0x4DFFFFFF),
          type: BottomNavigationBarType.fixed,
          elevation: 20,
        ),
      ),
      home: const MainScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}