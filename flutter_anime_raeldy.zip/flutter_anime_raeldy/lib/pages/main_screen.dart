import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/custom_bottom_nav.dart';
import 'home_page.dart';
import 'search_page.dart';
import 'favorite_page.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with TickerProviderStateMixin {
  int _currentIndex = 0;
  List<String> favoriteIds = [];
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      favoriteIds = prefs.getStringList('favorites') ?? [];
    });
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', favoriteIds);
  }

  void _toggleFavorite(String malId) {
    setState(() {
      if (favoriteIds.contains(malId)) {
        favoriteIds.remove(malId);
      } else {
        favoriteIds.add(malId);
      }
    });
    _saveFavorites();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          HomePage(
            favoriteIds: favoriteIds, 
            onToggleFavorite: _toggleFavorite,
          ),
          SearchPage(
            favoriteIds: favoriteIds,
            onToggleFavorite: _toggleFavorite,
          ),
          FavoritePage(
            favoriteIds: favoriteIds,
            onToggleFavorite: _toggleFavorite,
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        animationController: _animationController,
      ),
    );
  }
}