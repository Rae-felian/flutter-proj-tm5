import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/anime_model.dart';
import '../services/api_service.dart';
import '../widgets/category_section.dart';
import '../widgets/anime_detail_modal.dart';

class HomePage extends StatefulWidget {
  final List<String> favoriteIds;
  final Function(String) onToggleFavorite;

  const HomePage({
    super.key,
    required this.favoriteIds,
    required this.onToggleFavorite,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with AutomaticKeepAliveClientMixin {
  final ApiService _apiService = ApiService();
  
  Map<String, List<Anime>> categoriesData = {
    'trending': [],
    'top_rated': [],
    'popular': [],
  };
  
  Map<String, bool> loadingStates = {
    'trending': true,
    'top_rated': true,
    'popular': true,
  };
  
  String errorMessage = '';

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _fetchAllCategories();
  }

  Future<void> _fetchAllCategories() async {
    HapticFeedback.selectionClick();
    
    // Reset error message
    setState(() {
      errorMessage = '';
    });
    
    await Future.wait([
      _fetchTrending(),
      _fetchTopRated(),
      _fetchMostPopular(),
    ]);
  }

  Future<void> _fetchTrending() async {
    try {
      final animeList = await _apiService.getTrendingAnime(limit: 9);
      setState(() {
        categoriesData['trending'] = animeList;
        loadingStates['trending'] = false;
      });
    } catch (e) {
      setState(() {
        loadingStates['trending'] = false;
        errorMessage = 'Gagal memuat data trending: $e';
      });
    }
  }

  Future<void> _fetchTopRated() async {
    try {
      final animeList = await _apiService.getTopRatedAnime(limit: 9);
      setState(() {
        categoriesData['top_rated'] = animeList;
        loadingStates['top_rated'] = false;
      });
    } catch (e) {
      setState(() {
        loadingStates['top_rated'] = false;
        errorMessage = 'Gagal memuat data top rated: $e';
      });
    }
  }

  Future<void> _fetchMostPopular() async {
    try {
      final animeList = await _apiService.getMostPopularAnime(limit: 9);
      setState(() {
        categoriesData['popular'] = animeList;
        loadingStates['popular'] = false;
      });
    } catch (e) {
      setState(() {
        loadingStates['popular'] = false;
        errorMessage = 'Gagal memuat data popular: $e';
      });
    }
  }

  void _showAnimeDetail(Anime anime, bool isFavorite) {
    AnimeDetailModal.show(
      context,
      anime: anime,
      isFavorite: isFavorite,
      onToggleFavorite: widget.onToggleFavorite,
    );
  }

  void _showSeeAllPage(String categoryTitle, List<Anime> animeList) {
    // TODO: Implement see all page navigation
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$categoryTitle - Lihat Semua (Coming Soon!)'),
        backgroundColor: const Color(0xFF00ff88),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      body: RefreshIndicator(
        color: const Color(0xFF00ff88),
        onRefresh: () async {
          setState(() {
            loadingStates = {
              'trending': true,
              'top_rated': true,
              'popular': true,
            };
            errorMessage = '';
          });
          await _fetchAllCategories();
        },
        child: CustomScrollView(
          slivers: [
            // Enhanced App Bar
            SliverAppBar(
              expandedHeight: 120,
              floating: false,
              pinned: true,
              backgroundColor: const Color(0xFF1a1a1a),
              flexibleSpace: FlexibleSpaceBar(
                title: ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [Color(0xFF00ff88), Color(0xFF00ccff)],
                  ).createShader(bounds),
                  child: const Text(
                    'RanimeList',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                centerTitle: false,
                titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
                background: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        const Color(0xFF1a1a1a),
                        const Color(0xCC2a2a2a),
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                Container(
                  margin: const EdgeInsets.only(right: 20, top: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0x3300ff88),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0x8000ff88)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.favorite, color: Color(0xFF00ff88), size: 16),
                      const SizedBox(width: 4),
                      Text(
                        '${widget.favoriteIds.length}',
                        style: const TextStyle(
                          color: Color(0xFF00ff88),
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // Content dengan 3 Kategori
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    // Error message jika ada
                    if (errorMessage.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.red.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline, color: Colors.red),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                errorMessage,
                                style: const TextStyle(color: Colors.red),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],

                    // Trending Now Section
                    CategorySection(
                      title: '🔥 Trending Now',
                      subtitle: 'Anime yang sedang populer',
                      animeList: categoriesData['trending'] ?? [],
                      isLoading: loadingStates['trending'] ?? true,
                      favoriteIds: widget.favoriteIds,
                      onToggleFavorite: widget.onToggleFavorite,
                      onAnimeSelected: _showAnimeDetail,
                      onSeeAll: () => _showSeeAllPage('Trending Now', categoriesData['trending'] ?? []),
                    ),
                    
                    const SizedBox(height: 32),
                    
                    // Highest Rated Section
                    CategorySection(
                      title: '⭐ Highest Rated',
                      subtitle: 'Anime dengan rating tertinggi',
                      animeList: categoriesData['top_rated'] ?? [],
                      isLoading: loadingStates['top_rated'] ?? true,
                      favoriteIds: widget.favoriteIds,
                      onToggleFavorite: widget.onToggleFavorite,
                      onAnimeSelected: _showAnimeDetail,
                      onSeeAll: () => _showSeeAllPage('Highest Rated', categoriesData['top_rated'] ?? []),
                    ),
                    
                    const SizedBox(height: 32),
                    
                    // Most Popular Section
                    CategorySection(
                      title: '🔥 Most Popular',
                      subtitle: 'Anime paling populer sepanjang masa',
                      animeList: categoriesData['popular'] ?? [],
                      isLoading: loadingStates['popular'] ?? true,
                      favoriteIds: widget.favoriteIds,
                      onToggleFavorite: widget.onToggleFavorite,
                      onAnimeSelected: _showAnimeDetail,
                      onSeeAll: () => _showSeeAllPage('Most Popular', categoriesData['popular'] ?? []),
                    ),
                    
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}