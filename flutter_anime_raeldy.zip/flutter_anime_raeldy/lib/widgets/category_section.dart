import 'package:flutter/material.dart';
import '../models/anime_model.dart';
import 'anime_grid_card.dart';

class CategorySection extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Anime> animeList;
  final bool isLoading;
  final VoidCallback onSeeAll;
  final List<String> favoriteIds;
  final Function(String) onToggleFavorite;
  final Function(Anime, bool) onAnimeSelected;

  const CategorySection({
    super.key,
    required this.title,
    required this.subtitle,
    required this.animeList,
    required this.isLoading,
    required this.onSeeAll,
    required this.favoriteIds,
    required this.onToggleFavorite,
    required this.onAnimeSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section Header
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white60,
                  ),
                ),
              ],
            ),
            TextButton.icon(
              onPressed: animeList.isNotEmpty ? onSeeAll : null,
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF00ff88),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              icon: const Icon(Icons.arrow_forward_rounded, size: 16),
              label: const Text(
                'Lihat Semua',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        
        const SizedBox(height: 16),
        
        // 3x3 Grid Container
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF1a1a1a),
                const Color(0xFF2a2a2a),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: const Color(0x2000ff88),
                blurRadius: 20,
                spreadRadius: 2,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          padding: const EdgeInsets.all(16),
          child: isLoading 
              ? _buildLoadingGrid()
              : animeList.isEmpty 
                  ? _buildEmptyGrid()
                  : _buildAnimeGrid(),
        ),
      ],
    );
  }

  Widget _buildAnimeGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.7, // Portrait ratio
      ),
      itemCount: animeList.length > 9 ? 9 : animeList.length,
      itemBuilder: (context, index) {
        final anime = animeList[index];
        final isFavorite = favoriteIds.contains(anime.malId.toString());
        
        return AnimeGridCard(
          anime: anime,
          isFavorite: isFavorite,
          onTap: () => onAnimeSelected(anime, isFavorite),
          onFavoriteToggle: () => onToggleFavorite(anime.malId.toString()),
        );
      },
    );
  }

  Widget _buildLoadingGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.7,
      ),
      itemCount: 9,
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.grey[800],
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Center(
            child: CircularProgressIndicator(
              color: Color(0xFF00ff88),
              strokeWidth: 2,
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyGrid() {
    return Container(
      height: 200,
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline_rounded,
              color: Colors.red,
              size: 32,
            ),
            SizedBox(height: 8),
            Text(
              'Gagal memuat data',
              style: TextStyle(color: Colors.red),
            ),
          ],
        ),
      ),
    );
  }
}