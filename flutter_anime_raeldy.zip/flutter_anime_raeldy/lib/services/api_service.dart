import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/anime_model.dart';

class ApiService {
  static const String baseUrl = 'https://api.jikan.moe/v4';
  
  // Singleton pattern untuk efficient resource usage
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  // Get trending anime (currently airing)
  Future<List<Anime>> getTrendingAnime({int limit = 9}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/top/anime?filter=airing&limit=$limit'),
      );
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> dataList = jsonData['data'];
        
        return dataList.map((json) => Anime.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load trending anime');
      }
    } catch (e) {
      throw Exception('Error fetching trending anime: $e');
    }
  }

  // Get top rated anime
  Future<List<Anime>> getTopRatedAnime({int limit = 9}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/top/anime?limit=$limit'),
      );
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> dataList = jsonData['data'];
        
        return dataList.map((json) => Anime.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load top rated anime');
      }
    } catch (e) {
      throw Exception('Error fetching top rated anime: $e');
    }
  }

  // Get most popular anime
  Future<List<Anime>> getMostPopularAnime({int limit = 9}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/top/anime?filter=bypopularity&limit=$limit'),
      );
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> dataList = jsonData['data'];
        
        return dataList.map((json) => Anime.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load popular anime');
      }
    } catch (e) {
      throw Exception('Error fetching popular anime: $e');
    }
  }

  // Search anime by query
  Future<List<Anime>> searchAnime(String query, {int limit = 20}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/anime?q=${Uri.encodeComponent(query)}&limit=$limit'),
      );
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> dataList = jsonData['data'];
        
        return dataList.map((json) => Anime.fromJson(json)).toList();
      } else {
        throw Exception('Failed to search anime');
      }
    } catch (e) {
      throw Exception('Error searching anime: $e');
    }
  }

  // Get anime by ID (for detailed info)
  Future<Anime> getAnimeById(int id) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/anime/$id'),
      );
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        return Anime.fromJson(jsonData['data']);
      } else {
        throw Exception('Failed to load anime details');
      }
    } catch (e) {
      throw Exception('Error fetching anime details: $e');
    }
  }

  // Get seasonal anime
  Future<List<Anime>> getSeasonalAnime({
    int? year, 
    String? season, 
    int limit = 25
  }) async {
    try {
      String url = '$baseUrl/seasons';
      if (year != null && season != null) {
        url += '/$year/$season';
      } else {
        url += '/now';
      }
      url += '?limit=$limit';

      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> dataList = jsonData['data'];
        
        return dataList.map((json) => Anime.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load seasonal anime');
      }
    } catch (e) {
      throw Exception('Error fetching seasonal anime: $e');
    }
  }

  // Get anime by genre
  Future<List<Anime>> getAnimeByGenre(int genreId, {int limit = 25}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/anime?genres=$genreId&limit=$limit'),
      );
      
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> dataList = jsonData['data'];
        
        return dataList.map((json) => Anime.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load anime by genre');
      }
    } catch (e) {
      throw Exception('Error fetching anime by genre: $e');
    }
  }
}